<?PHP

$index = 1;
include("header.inc");
include("index.inc");
include("footer.inc");
?>
