document.write('<a href="mailto:');
document.write('michael');
document.write('@');
document.write('abetterpruning.com');
document.write('">');

document.write('michael');
document.write('@');
document.write('abetterpruning.com<\/a>');
