<?PHP
$specials = 1;
include("header.inc");
include("specials.inc");
include("footer.inc");
?>
