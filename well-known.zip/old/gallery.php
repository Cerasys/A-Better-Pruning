<?PHP
$gallery = 1;
include("header.inc");
include("gallery.inc");
include("footer.inc");
?>
