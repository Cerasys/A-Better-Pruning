<?PHP
$resources = 1;
include("header.inc");
include("resources.inc");
include("footer.inc");
?>
