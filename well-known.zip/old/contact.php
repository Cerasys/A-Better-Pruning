<?PHP
$contact = 1;
include("header.inc");
include("contact.inc");
include("footer.inc");
?>
